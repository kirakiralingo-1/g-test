/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file cargo_type.h Types related to cargoes... */

#ifndef CARGO_TYPE_H
#define CARGO_TYPE_H

#include "core/label_type.hpp"
#include "core/enum_type.hpp"

/** Globally unique label of a cargo type. */
using CargoLabel = Label<struct CargoLabelTag>;

/**
 * Cargo slots to indicate a cargo type within a game.
 */
enum CargoType : uint8_t {};
DECLARE_INCREMENT_DECREMENT_OPERATORS(CargoType)

/**
 * @name Available types of cargo.
 * Labels may be re-used between different climates.
 * @{
 */

/* Temperate */
static constexpr CargoLabel CT_PASSENGERS{"PASS"}; ///< Cargo label for passengers.
static constexpr CargoLabel CT_COAL{"COAL"}; ///< Cargo label for coal.
static constexpr CargoLabel CT_MAIL{"MAIL"}; ///< Cargo label for mail.
static constexpr CargoLabel CT_OIL{"OIL_"}; ///< Cargo label for oil.
static constexpr CargoLabel CT_LIVESTOCK{"LVST"}; ///< Cargo label for livestock.
static constexpr CargoLabel CT_GOODS{"GOOD"}; ///< Cargo label for goods.
static constexpr CargoLabel CT_GRAIN{"GRAI"}; ///< Cargo label for grain.
static constexpr CargoLabel CT_WOOD{"WOOD"}; ///< Cargo label for wood.
static constexpr CargoLabel CT_IRON_ORE{"IORE"}; ///< Cargo label for iron ore.
static constexpr CargoLabel CT_STEEL{"STEL"}; ///< Cargo label for steel.
static constexpr CargoLabel CT_VALUABLES{"VALU"}; ///< Cargo label for valuables.

/* Arctic */
static constexpr CargoLabel CT_WHEAT{"WHEA"}; ///< Cargo label for wheat.
static constexpr CargoLabel CT_PAPER{"PAPR"}; ///< Cargo label for paper.
static constexpr CargoLabel CT_GOLD{"GOLD"}; ///< Cargo label for gold.
static constexpr CargoLabel CT_FOOD{"FOOD"}; ///< Cargo label for food.

/* Tropic */
static constexpr CargoLabel CT_RUBBER{"RUBR"}; ///< Cargo label for rubber.
static constexpr CargoLabel CT_FRUIT{"FRUT"}; ///< Cargo label for fruits.
static constexpr CargoLabel CT_MAIZE{"MAIZ"}; ///< Cargo label for maize.
static constexpr CargoLabel CT_COPPER_ORE{"CORE"}; ///< Cargo label for copper ore.
static constexpr CargoLabel CT_WATER{"WATR"}; ///< Cargo label for water.
static constexpr CargoLabel CT_DIAMONDS{"DIAM"}; ///< Cargo label for diamonds.

/* Toyland */
static constexpr CargoLabel CT_SUGAR{"SUGR"}; ///< Cargo label for sugar.
static constexpr CargoLabel CT_TOYS{"TOYS"}; ///< Cargo label for toys.
static constexpr CargoLabel CT_BATTERIES{"BATT"}; ///< Cargo label for batteries.
static constexpr CargoLabel CT_CANDY{"SWET"}; ///< Cargo label for candies/sweets.
static constexpr CargoLabel CT_TOFFEE{"TOFF"}; ///< Cargo label for toffee.
static constexpr CargoLabel CT_COLA{"COLA"}; ///< Cargo label for cola.
static constexpr CargoLabel CT_COTTON_CANDY{"CTCD"}; ///< Cargo label for cotton candies.
static constexpr CargoLabel CT_BUBBLES{"BUBL"}; ///< Cargo label for bubbles.
static constexpr CargoLabel CT_PLASTIC{"PLST"}; ///< Cargo label for plastic.
static constexpr CargoLabel CT_FIZZY_DRINKS{"FZDR"}; ///< Cargo label for fizzy drinks.
/** @} */

/** Dummy label for engines that carry no cargo; they actually carry 0 passengers. */
static constexpr CargoLabel CT_NONE = CT_PASSENGERS;

static constexpr CargoLabel CT_INVALID{"\xFF\xFF\xFF\xFF"}; ///< Invalid cargo type.

static constexpr CargoType NUM_ORIGINAL_CARGO{12}; ///< Original number of cargo types.
static constexpr CargoType NUM_CARGO{64}; ///< Maximum number of cargo types in a game.

/* CARGO_AUTO_REFIT and CARGO_NO_REFIT are stored in save-games for refit-orders, so should not be changed. */
static constexpr CargoType CARGO_AUTO_REFIT{0xFD}; ///< Automatically choose cargo type when doing auto refitting.
static constexpr CargoType CARGO_NO_REFIT{0xFE}; ///< Do not refit cargo of a vehicle (used in vehicle orders and auto-replace/auto-renew).

static constexpr CargoType INVALID_CARGO{UINT8_MAX}; ///< Invalid marker for cargoes.

/** Mixed cargo types for definitions with cargo that can vary depending on climate. */
enum MixedCargoType : uint8_t {
	MCT_LIVESTOCK_FRUIT, ///< Cargo can be livestock or fruit.
	MCT_GRAIN_WHEAT_MAIZE, ///< Cargo can be grain, wheat or maize.
	MCT_VALUABLES_GOLD_DIAMONDS, ///< Cargo can be valuables, gold or diamonds.
};

/**
 * Special cargo filter criteria.
 * These are used by user interface code only and must not be assigned to any entity. Not all values are valid for every UI filter.
 */
namespace CargoFilterCriteria {
	static constexpr CargoType CF_ANY{NUM_CARGO}; ///< Show all items independent of carried cargo (i.e. no filtering)
	static constexpr CargoType CF_NONE{NUM_CARGO + 1}; ///< Show only items which do not carry cargo (e.g. train engines)
	static constexpr CargoType CF_ENGINES{NUM_CARGO + 2}; ///< Show only engines (for rail vehicles only)
	static constexpr CargoType CF_FREIGHT{NUM_CARGO + 3}; ///< Show only vehicles which carry any freight (non-passenger) cargo

	static constexpr CargoType CF_NO_RATING{NUM_CARGO + 4}; ///< Show items with no rating (station list)
	static constexpr CargoType CF_SELECT_ALL{NUM_CARGO + 5}; ///< Select all items (station list)
	static constexpr CargoType CF_EXPAND_LIST{NUM_CARGO + 6}; ///< Expand list to show all items (station list)
};

/**
 * Test whether cargo type is not INVALID_CARGO.
 * @param cargo The cargo to check.
 * @return \c false iff the cargo is INVALID_CARGO.
 */
inline bool IsValidCargoType(CargoType cargo) { return cargo != INVALID_CARGO; }

/** Bitset of \c CargoType elements. */
using CargoTypes = EnumBitSet<CargoType, uint64_t>;

static constexpr CargoTypes ALL_CARGOTYPES{UINT64_MAX};

/** Class for storing amounts of cargo */
struct CargoArray : std::array<uint, NUM_CARGO> {
	/**
	 * Get the sum of all cargo amounts.
	 * @return The sum.
	 */
	template <typename T>
	inline const T GetSum() const
	{
		return std::reduce(this->begin(), this->end(), T{});
	}

	/**
	 * Get the amount of cargos that have an amount.
	 * @return The amount.
	 */
	inline uint GetCount() const
	{
		return std::ranges::count_if(*this, [](uint amount) { return amount != 0; });
	}
};

#endif /* CARGO_TYPE_H */
