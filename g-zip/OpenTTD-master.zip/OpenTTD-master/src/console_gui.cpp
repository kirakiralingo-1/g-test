/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file console_gui.cpp Handling the GUI of the in-game console. */

#include "stdafx.h"
#include "core/string_consumer.hpp"
#include "textbuf_type.h"
#include "window_gui.h"
#include "autocompletion.h"
#include "console_gui.h"
#include "console_internal.h"
#include "window_func.h"
#include "string_func.h"
#include "strings_func.h"
#include "gfx_func.h"
#include "gfx_layout.h"
#include "settings_type.h"
#include "console_func.h"
#include "rev.h"
#include "video/video_driver.hpp"
#include "timer/timer.h"
#include "timer/timer_window.h"

#include "widgets/console_widget.h"

#include "table/strings.h"

#include "safeguards.h"

static const uint ICON_HISTORY_SIZE       = 20;
static const uint ICON_RIGHT_BORDERWIDTH  = 10;
static const uint ICON_BOTTOM_BORDERWIDTH = 12;

/**
 * Container for a single line of console output
 */
struct IConsoleLine {
	std::string buffer;     ///< The data to store.
	ExtendedTextColour colour; ///< The colour of the line.
	uint16_t time;            ///< The amount of time the line is in the backlog.

	IConsoleLine() : buffer(), colour(TextColour::Begin), time(0)
	{

	}

	/**
	 * Initialize the console line.
	 * @param buffer the data to print.
	 * @param colour the colour of the line.
	 */
	IConsoleLine(std::string buffer, ExtendedTextColour colour) :
			buffer(std::move(buffer)),
			colour(colour),
			time(0)
	{
	}

	~IConsoleLine()
	{
	}
};

/** The console backlog buffer. Item index 0 is the newest line. */
static std::deque<IConsoleLine> _iconsole_buffer;

static bool TruncateBuffer();

class ConsoleAutoCompletion final : public AutoCompletion {
public:
	using AutoCompletion::AutoCompletion;

private:
	std::vector<std::string> GetSuggestions(std::string_view prefix, std::string_view query) override
	{
		prefix = StrTrimView(prefix, StringConsumer::WHITESPACE_NO_NEWLINE);
		std::vector<std::string> suggestions;

		/* We only suggest commands or aliases, so we only do it for the first token or an argument to help command. */
		if (!prefix.empty() && prefix != "help") {
			return suggestions;
		}

		for (const auto &[_, command] : IConsole::Commands()) {
			if (command.name.starts_with(query)) {
				suggestions.push_back(command.name);
			}
		}
		for (const auto &[_, alias] : IConsole::Aliases()) {
			if (alias.name.starts_with(query)) {
				suggestions.push_back(alias.name);
			}
		}

		return suggestions;
	}

	void ApplySuggestion(std::string_view prefix, std::string_view suggestion) override
	{
		this->textbuf->Assign(fmt::format("{}{} ", prefix, suggestion));
	}
};

/** Main console cmd buffer. */
static Textbuf _iconsole_cmdline(ICON_CMDLN_SIZE);
static ConsoleAutoCompletion _iconsole_tab_completion(&_iconsole_cmdline);
static std::deque<std::string> _iconsole_history;
static ptrdiff_t _iconsole_historypos;
IConsoleMode _iconsole_mode;

/* *************** *
 *  end of header  *
 * *************** */

static void IConsoleClearCommand()
{
	_iconsole_cmdline.DeleteAll();
	_iconsole_tab_completion.Reset();
	SetWindowDirty(WindowClass::Console, 0);
}

static inline void IConsoleResetHistoryPos()
{
	_iconsole_historypos = -1;
}


static std::optional<std::string_view> IConsoleHistoryAdd(std::string_view cmd);
static void IConsoleHistoryNavigate(int direction);

static constexpr std::initializer_list<NWidgetPart> _nested_console_window_widgets = {
	NWidget(WWT_EMPTY, Colours::Invalid, WID_C_BACKGROUND), SetResize(1, 1),
};

/** Window definition for the console window. */
static WindowDesc _console_window_desc(
	WindowPosition::Manual, {}, 0, 0,
	WindowClass::Console, WindowClass::None,
	{},
	_nested_console_window_widgets
);

struct IConsoleWindow : Window
{
	static size_t scroll;
	int line_height = 0; ///< Height of one line of text in the console.
	int line_offset = 0;
	int cursor_width = 0;

	IConsoleWindow() : Window(_console_window_desc)
	{
		_iconsole_mode = IConsoleMode::Opened;

		this->InitNested(0);
		ResizeWindow(this, _screen.width, _screen.height / 3);
	}

	void OnInit() override
	{
		this->line_height = GetCharacterHeight(FontSize::Normal) + WidgetDimensions::scaled.hsep_normal;
		this->line_offset = GetStringBoundingBox("] ").width + WidgetDimensions::scaled.frametext.left;
		this->cursor_width = GetCharacterWidth(FontSize::Normal, '_');
	}

	void Close([[maybe_unused]] int data = 0) override
	{
		_iconsole_mode = IConsoleMode::Closed;
		VideoDriver::GetInstance()->EditBoxLostFocus();
		this->Window::Close();
	}

	/**
	 * Scroll the content of the console.
	 * @param amount Number of lines to scroll back.
	 */
	void Scroll(int amount)
	{
		if (amount < 0) {
			size_t namount = static_cast<size_t>(-amount);
			IConsoleWindow::scroll = (namount > IConsoleWindow::scroll) ? 0 : IConsoleWindow::scroll - namount;
		} else {
			assert(this->height >= 0 && this->line_height > 0);
			size_t visible_lines = static_cast<size_t>(this->height / this->line_height);
			size_t max_scroll = (visible_lines > _iconsole_buffer.size()) ? 0 : _iconsole_buffer.size() + 1 - visible_lines;
			IConsoleWindow::scroll = std::min<size_t>(IConsoleWindow::scroll + amount, max_scroll);
		}
		this->SetDirty();
	}

	void OnPaint() override
	{
		const int right = this->width - WidgetDimensions::scaled.frametext.right;

		GfxFillRect(0, 0, this->width - 1, this->height - 1, PC_BLACK);
		int ypos = this->height - this->line_height - WidgetDimensions::scaled.hsep_normal;
		for (size_t line_index = IConsoleWindow::scroll; line_index < _iconsole_buffer.size(); line_index++) {
			const IConsoleLine &print = _iconsole_buffer[line_index];
			ypos = DrawStringMultiLine(WidgetDimensions::scaled.frametext.left, right, -this->line_height, ypos, GetString(STR_JUST_RAW_STRING, print.buffer), print.colour, {AlignmentH::ForceLeft, AlignmentV::Bottom}) - WidgetDimensions::scaled.hsep_normal;
			if (ypos < 0) break;
		}
		/* If the text is longer than the window, don't show the starting ']' */
		int delta = this->width - WidgetDimensions::scaled.frametext.right - cursor_width - this->line_offset - _iconsole_cmdline.pixels - ICON_RIGHT_BORDERWIDTH;
		if (delta > 0) {
			DrawString(WidgetDimensions::scaled.frametext.left, right, this->height - this->line_height, "]", CC_COMMAND, AlignmentH::ForceLeft);
			delta = 0;
		}

		/* If we have a marked area, draw a background highlight. */
		if (_iconsole_cmdline.marklength != 0) GfxFillRect(this->line_offset + delta + _iconsole_cmdline.markxoffs, this->height - this->line_height, this->line_offset + delta + _iconsole_cmdline.markxoffs + _iconsole_cmdline.marklength, this->height - 1, PC_DARK_RED);

		DrawString(this->line_offset + delta, right, this->height - this->line_height, _iconsole_cmdline.GetText(), CC_COMMAND, AlignmentH::ForceLeft);

		if (_focused_window == this && _iconsole_cmdline.caret) {
			DrawString(this->line_offset + delta + _iconsole_cmdline.caretxoffs, right, this->height - this->line_height, "_", TextColour::White, AlignmentH::ForceLeft);
		}
	}

	/** Check on a regular interval if the console buffer needs truncating. */
	const IntervalTimer<TimerWindow> truncate_interval = {std::chrono::seconds(3), [this](auto) {
		assert(this->height >= 0 && this->line_height > 0);
		size_t visible_lines = static_cast<size_t>(this->height / this->line_height);

		if (TruncateBuffer() && IConsoleWindow::scroll + visible_lines > _iconsole_buffer.size()) {
			size_t max_scroll = (visible_lines > _iconsole_buffer.size()) ? 0 : _iconsole_buffer.size() + 1 - visible_lines;
			IConsoleWindow::scroll = std::min<size_t>(IConsoleWindow::scroll, max_scroll);
			this->SetDirty();
		}
	}};

	void OnMouseLoop() override
	{
		if (_iconsole_cmdline.HandleCaret()) this->SetDirty();
	}

	EventState OnKeyPress([[maybe_unused]] char32_t key, uint16_t keycode) override
	{
		if (_focused_window != this) return EventState::NotHandled;

		const int scroll_height = (this->height / this->line_height) - 1;
		switch (keycode) {
			case WKC_UP:
				IConsoleHistoryNavigate(1);
				this->SetDirty();
				break;

			case WKC_DOWN:
				IConsoleHistoryNavigate(-1);
				this->SetDirty();
				break;

			case WKC_SHIFT | WKC_PAGEDOWN:
				this->Scroll(-scroll_height);
				break;

			case WKC_SHIFT | WKC_PAGEUP:
				this->Scroll(scroll_height);
				break;

			case WKC_SHIFT | WKC_DOWN:
				this->Scroll(-1);
				break;

			case WKC_SHIFT | WKC_UP:
				this->Scroll(1);
				break;

			case WKC_BACKQUOTE:
				IConsoleSwitch();
				break;

			case WKC_RETURN: case WKC_NUM_ENTER: {
				/* We always want the ] at the left side; we always force these strings to be left
				 * aligned anyway. So enforce this in all cases by adding a left-to-right marker,
				 * otherwise it will be drawn at the wrong side with right-to-left texts. */
				IConsolePrint(CC_COMMAND, LRM "] {}", _iconsole_cmdline.GetText());
				auto cmd = IConsoleHistoryAdd(_iconsole_cmdline.GetText());
				IConsoleClearCommand();

				if (cmd.has_value()) IConsoleCmdExec(*cmd);
				break;
			}

			case WKC_CTRL | WKC_RETURN:
				_iconsole_mode = (_iconsole_mode == IConsoleMode::Full) ? IConsoleMode::Opened : IConsoleMode::Full;
				IConsoleResize(this);
				MarkWholeScreenDirty();
				break;

			case (WKC_CTRL | 'L'):
				IConsoleCmdExec("clear");
				break;

			case WKC_TAB:
				if (_iconsole_tab_completion.AutoComplete()) {
					this->SetDirty();
				}
				break;

			default: {
				HandleKeyPressResult handle_result = _iconsole_cmdline.HandleKeyPress(key, keycode);
				if (handle_result != HKPR_NOT_HANDLED) {
					if (handle_result == HKPR_EDITING) {
						_iconsole_tab_completion.Reset();
					}
					IConsoleWindow::scroll = 0;
					IConsoleResetHistoryPos();
					this->SetDirty();
				} else {
					return EventState::NotHandled;
				}
				break;
			}
		}
		return EventState::Handled;
	}

	void InsertTextString(WidgetID, std::string_view str, bool marked, std::optional<size_t> caret, std::optional<size_t> insert_location, std::optional<size_t> replacement_end) override
	{
		if (_iconsole_cmdline.InsertString(str, marked, caret, insert_location, replacement_end)) {
			_iconsole_tab_completion.Reset();
			IConsoleWindow::scroll = 0;
			IConsoleResetHistoryPos();
			this->SetDirty();
		}
	}

	const Textbuf *GetFocusedTextbuf() const override
	{
		return &_iconsole_cmdline;
	}

	Point GetCaretPosition() const override
	{
		int delta = std::min<int>(this->width - this->line_offset - _iconsole_cmdline.pixels - ICON_RIGHT_BORDERWIDTH, 0);
		Point pt = {this->line_offset + delta + _iconsole_cmdline.caretxoffs, this->height - this->line_height};

		return pt;
	}

	Rect GetTextBoundingRect(size_t from, size_t to) const override
	{
		int delta = std::min<int>(this->width - this->line_offset - _iconsole_cmdline.pixels - ICON_RIGHT_BORDERWIDTH, 0);

		const auto p1 = GetCharPosInString(_iconsole_cmdline.GetText(), from, FontSize::Normal);
		const auto p2 = from != to ? GetCharPosInString(_iconsole_cmdline.GetText(), to, FontSize::Normal) : p1;

		Rect r = {this->line_offset + delta + p1.left, this->height - this->line_height, this->line_offset + delta + p2.right, this->height};
		return r;
	}

	ptrdiff_t GetTextCharacterAtPosition(const Point &pt) const override
	{
		int delta = std::min<int>(this->width - this->line_offset - _iconsole_cmdline.pixels - ICON_RIGHT_BORDERWIDTH, 0);

		if (!IsInsideMM(pt.y, this->height - this->line_height, this->height)) return -1;

		return GetCharAtPosition(_iconsole_cmdline.GetText(), pt.x - delta);
	}

	void OnMouseWheel(int wheel, WidgetID widget) override
	{
		if (widget != WID_C_BACKGROUND) return;
		this->Scroll(-wheel);
	}

	void OnFocus() override
	{
		VideoDriver::GetInstance()->EditBoxGainedFocus();
	}

	void OnFocusLost(bool) override
	{
		VideoDriver::GetInstance()->EditBoxLostFocus();
	}
};

size_t IConsoleWindow::scroll = 0;

void IConsoleGUIInit()
{
	IConsoleResetHistoryPos();
	_iconsole_mode = IConsoleMode::Closed;

	IConsoleClearBuffer();

	IConsolePrint(TextColour::LightBlue, "OpenTTD Game Console Revision 7 - {}", _openttd_revision);
	IConsolePrint(CC_WHITE, "------------------------------------");
	IConsolePrint(CC_WHITE, "use \"help\" for more information.");
	IConsolePrint(CC_WHITE, "");
	IConsoleClearCommand();
}

void IConsoleClearBuffer()
{
	_iconsole_buffer.clear();
}

void IConsoleGUIFree()
{
	IConsoleClearBuffer();
}

/**
 * Change the size of the in-game console window after the screen size changed, or the window state changed.
 * @param w The window to update.
 */
void IConsoleResize(Window *w)
{
	switch (_iconsole_mode) {
		case IConsoleMode::Opened:
			w->height = _screen.height / 3;
			w->width = _screen.width;
			break;
		case IConsoleMode::Full:
			w->height = _screen.height - ICON_BOTTOM_BORDERWIDTH;
			w->width = _screen.width;
			break;
		default: return;
	}

	MarkWholeScreenDirty();
}

/** Toggle in-game console between opened and closed. */
void IConsoleSwitch()
{
	switch (_iconsole_mode) {
		case IConsoleMode::Closed:
			new IConsoleWindow();
			break;

		case IConsoleMode::Opened:
		case IConsoleMode::Full:
			CloseWindowById(WindowClass::Console, 0);
			break;
	}

	MarkWholeScreenDirty();
}

/** Close the in-game console. */
void IConsoleClose()
{
	if (_iconsole_mode == IConsoleMode::Opened) IConsoleSwitch();
}

/**
 * Add the entered line into the history so you can look it back
 * scroll, etc. Put it to the beginning as it is the latest text
 * @param cmd Text to be entered into the 'history'
 * @return the command to execute
 */
static std::optional<std::string_view> IConsoleHistoryAdd(std::string_view cmd)
{
	/* Strip all spaces at the begin */
	while (!cmd.empty() && IsWhitespace(cmd[0])) cmd.remove_prefix(1);

	/* Do not put empty command in history */
	if (cmd.empty()) return std::nullopt;

	/* Do not put in history if command is same as previous */
	if (_iconsole_history.empty() || _iconsole_history.front() != cmd) {
		_iconsole_history.emplace_front(cmd);
		while (_iconsole_history.size() > ICON_HISTORY_SIZE) _iconsole_history.pop_back();
	}

	/* Reset the history position */
	IConsoleResetHistoryPos();
	return _iconsole_history.front();
}

/**
 * Navigate Up/Down in the history of typed commands
 * @param direction Go further back in history (+1), go to recently typed commands (-1)
 */
static void IConsoleHistoryNavigate(int direction)
{
	if (_iconsole_history.empty()) return; // Empty history
	_iconsole_historypos = Clamp<ptrdiff_t>(_iconsole_historypos + direction, -1, _iconsole_history.size() - 1);

	if (_iconsole_historypos == -1) {
		_iconsole_cmdline.DeleteAll();
	} else {
		_iconsole_cmdline.Assign(_iconsole_history[_iconsole_historypos]);
	}
	_iconsole_tab_completion.Reset();
}

/**
 * Handle the printing of text entered into the console or redirected there
 * by any other means. Text can be redirected to other clients in a network game
 * as well as to a logfile. If the network server is a dedicated server, all activities
 * are also logged. All lines to print are added to a temporary buffer which can be
 * used as a history to print them onscreen
 * @param colour_code the colour of the command. Red in case of errors, etc.
 * @param str the message entered or output on the console (notice, error, etc.)
 */
void IConsoleGUIPrint(ExtendedTextColour colour_code, const std::string &str)
{
	_iconsole_buffer.push_front(IConsoleLine(str, colour_code));
	SetWindowDirty(WindowClass::Console, 0);
}

/**
 * Remove old lines from the backlog buffer.
 * The buffer is limited by a maximum size and a minimum age. Every time truncation runs,
 * all lines in the buffer are aged by one. When a line exceeds both the maximum position
 * and also the maximum age, it gets removed.
 * @return true if any lines were removed
 */
static bool TruncateBuffer()
{
	bool need_truncation = false;
	size_t count = 0;
	for (IConsoleLine &line : _iconsole_buffer) {
		count++;
		line.time++;
		if (line.time > _settings_client.gui.console_backlog_timeout && count > _settings_client.gui.console_backlog_length) {
			/* Any messages after this are older and need to be truncated */
			need_truncation = true;
			break;
		}
	}

	if (need_truncation) {
		_iconsole_buffer.resize(count - 1);
	}

	return need_truncation;
}


/**
 * Check whether the given TextColour is valid for console usage.
 * @param c The text colour to compare to.
 * @return true iff the TextColour is valid for console usage.
 */
bool IsValidConsoleColour(ExtendedTextColour c)
{
	/* A normal text colour is used. */
	if (!c.flags.Test(ExtendedTextColourFlag::IsPaletteColour)) return TextColour::Begin <= c.colour && c.colour < TextColour::End;

	/* A text colour from the palette is used; must be the company
	 * colour gradient, so it must be one of those. */
	for (Colours i : EnumRange(Colours::End)) {
		if (ExtendedTextColour{GetColourGradient(i, Shade::Normal)} == c) return true;
	}

	return false;
}
