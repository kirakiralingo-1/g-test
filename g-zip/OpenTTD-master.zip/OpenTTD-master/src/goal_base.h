/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file goal_base.h %Goal base class. */

#ifndef GOAL_BASE_H
#define GOAL_BASE_H

#include "company_type.h"
#include "goal_type.h"
#include "core/pool_type.hpp"
#include "strings_type.h"

using GoalPool = Pool<Goal, GoalID, 64>;
extern GoalPool _goal_pool;

/** Struct about goals, current and completed */
struct Goal : GoalPool::PoolItem<&_goal_pool> {
	CompanyID company = CompanyID::Invalid(); ///< Goal is for a specific company; CompanyID::Invalid() if it is global
	GoalType type = GoalType::None; ///< Type of the goal
	GoalTypeID dst = 0; ///< Index of type
	EncodedString text{}; ///< Text of the goal.
	EncodedString progress{}; ///< Progress text of the goal.
	bool completed = false; ///< Is the goal completed or not?

	/**
	 * Construct the goal.
	 * @param index The index within the goal pool.
	 * @param type The goal type.
	 * @param dst The goal target.
	 * @param company The company for the goal.
	 * @param text The text of the goal.
	 */
	Goal(GoalID index, GoalType type = GoalType::None, GoalTypeID dst = 0, CompanyID company = CompanyID::Invalid(), const EncodedString &text = {}) :
		GoalPool::PoolItem<&_goal_pool>(index), company(company), type(type), dst(dst), text(text) {}

	/**
	 * (Empty) destructor has to be defined else operator delete might be called with nullptr parameter
	 */
	~Goal() { }

	static bool IsValidGoalDestination(CompanyID company, GoalType type, GoalTypeID dest);
};

#endif /* GOAL_BASE_H */
