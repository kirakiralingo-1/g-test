/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file highscore_gui.cpp Definition of the HighScore and EndGame windows. */

#include "stdafx.h"
#include "highscore.h"
#include "gfx_func.h"
#include "table/sprites.h"
#include "window_gui.h"
#include "window_func.h"
#include "network/network.h"
#include "command_func.h"
#include "company_func.h"
#include "company_base.h"
#include "strings_func.h"
#include "hotkeys.h"
#include "zoom_func.h"
#include "misc_cmd.h"
#include "timer/timer.h"
#include "timer/timer_game_calendar.h"

#include "widgets/highscore_widget.h"

#include "table/strings.h"

#include "safeguards.h"

struct EndGameHighScoreBaseWindow : Window {
	SpriteID background_img{};
	int8_t rank = 0;

	EndGameHighScoreBaseWindow(WindowDesc &desc) : Window(desc)
	{
		this->InitNested();
		this->flags.Reset(WindowFlag::WhiteBorder);
		ResizeWindow(this, _screen.width - this->width, _screen.height - this->height);
	}

	/** Always draw a maximized window and within it the centered background. */
	void SetupHighScoreEndWindow()
	{
		/* Resize window to "full-screen". */
		if (this->width != _screen.width || this->height != _screen.height) ResizeWindow(this, _screen.width - this->width, _screen.height - this->height);

		this->DrawWidgets();

		/* Fill with the appropriate background colour instead of leaving default window colour */
		GfxFillRect(Rect{0, 0, this->width, this->height}, PixelColour{105}, FillRectMode::Opaque);

		/* Standard background slices are 50 pixels high, but it's designed
		 * for 480 pixels total. 96% of 500 is 480. */
		Dimension dim = GetSpriteSize(this->background_img);
		auto total_height = dim.height * 96 / 10;
		Point pt = this->GetTopLeft(dim.width, total_height);

		/* Original graphics contain some transparency, which assumes a black background. */
		GfxFillRect(pt.x, pt.y, pt.x + dim.width - 1, pt.y + total_height - 1, PC_BLACK);

		/* Center Highscore/Endscreen background */
		for (uint i = 0; i < 10; i++) { // the image is split into 10 50px high parts
			DrawSprite(this->background_img + i, PAL_NONE, pt.x, pt.y + (i * dim.height));
		}
	}

	/**
	 * Return the coordinate of the screen such that a window of a given size is centered at the screen.
	 * @param width The width of the image.
	 * @param height The height of the image.
	 * @return The top left coordinate.
	 */
	Point GetTopLeft(int width, int height)
	{
		return {std::max(0, (_screen.width / 2) - (width / 2)), std::max(0, (_screen.height / 2) - (height / 2))};
	}

	void OnClick([[maybe_unused]] Point pt, [[maybe_unused]] WidgetID widget, [[maybe_unused]] int click_count) override
	{
		this->Close();
	}

	EventState OnKeyPress([[maybe_unused]] char32_t key, uint16_t keycode) override
	{
		/* All keys are 'handled' by this window but we want to make
		 * sure that 'quit' still works correctly. Not handling the
		 * quit key is enough so the main toolbar can handle it. */
		if (IsQuitKey(keycode)) return EventState::NotHandled;

		switch (keycode) {
			/* Keys for telling we want to go on */
			case WKC_RETURN:
			case WKC_ESC:
			case WKC_SPACE:
				this->Close();
				return EventState::Handled;

			default:
				/* We want to handle all keys; we don't want windows in
				 * the background to open. Especially the ones that do
				 * locate themselves based on the status-/toolbars. */
				return EventState::Handled;
		}
	}
};

/** End game window shown at the end of the game */
struct EndGameWindow : EndGameHighScoreBaseWindow {
	EndGameWindow(WindowDesc &desc) : EndGameHighScoreBaseWindow(desc)
	{
		/* Pause in single-player to have a look at the highscore at your own leisure */
		if (!_networking) Command<Commands::Pause>::Post(PauseMode::Normal, true);

		this->background_img = SPR_TYCOON_IMG1_BEGIN;

		if (_local_company != COMPANY_SPECTATOR) {
			const Company *c = Company::Get(_local_company);
			if (c->old_economy[0].performance_history == SCORE_MAX) {
				this->background_img = SPR_TYCOON_IMG2_BEGIN;
			}
		}

		/* In a network game show the endscores of the custom difficulty 'network' which is
		 * a TOP5 of that game, and not an all-time TOP5. */
		if (_networking) {
			this->window_number = SP_MULTIPLAYER;
			this->rank = SaveHighScoreValueNetwork();
		} else {
			/* in singleplayer mode _local company is always valid */
			const Company *c = Company::Get(_local_company);
			this->window_number = SP_CUSTOM;
			this->rank = SaveHighScoreValue(c);
		}

		MarkWholeScreenDirty();
	}

	void Close([[maybe_unused]] int data = 0) override
	{
		if (!_networking) Command<Commands::Pause>::Post(PauseMode::Normal, false); // unpause
		if (_game_mode != GameMode::Menu && !_exit_game) ShowHighscoreTable(this->window_number, this->rank);
		this->EndGameHighScoreBaseWindow::Close();
	}

	void OnPaint() override
	{
		this->SetupHighScoreEndWindow();
		Point pt = this->GetTopLeft(ScaleSpriteTrad(640), ScaleSpriteTrad(480));

		const Company *c = Company::GetIfValid(_local_company);
		if (c == nullptr) return;

		/* We need to get performance from last year because the image is shown
		 * at the start of the new year when these things have already been copied */
		if (this->background_img == SPR_TYCOON_IMG2_BEGIN) { // Tycoon of the century \o/
			DrawStringMultiLine(pt.x + ScaleSpriteTrad(15), pt.x + ScaleSpriteTrad(640) - ScaleSpriteTrad(25), pt.y + ScaleSpriteTrad(90), pt.y + ScaleSpriteTrad(160),
					GetString(STR_HIGHSCORE_PRESIDENT_OF_COMPANY_ACHIEVES_STATUS, c->index, c->index, EndGameGetPerformanceTitleFromValue(c->old_economy[0].performance_history)),
					TextColour::FromString, {AlignmentH::Centre, AlignmentV::Middle});
		} else {
			DrawStringMultiLine(pt.x + ScaleSpriteTrad(36), pt.x + ScaleSpriteTrad(640), pt.y + ScaleSpriteTrad(140), pt.y + ScaleSpriteTrad(206),
					GetString(STR_HIGHSCORE_COMPANY_ACHIEVES_STATUS, c->index, EndGameGetPerformanceTitleFromValue(c->old_economy[0].performance_history)),
					TextColour::FromString, {AlignmentH::Centre, AlignmentV::Middle});
		}
	}
};

struct HighScoreWindow : EndGameHighScoreBaseWindow {
	bool game_paused_by_player = false; ///< True if the game was paused by the player when the highscore window was opened.

	HighScoreWindow(WindowDesc &desc, int difficulty, int8_t ranking) : EndGameHighScoreBaseWindow(desc)
	{
		/* pause game to show the chart */
		this->game_paused_by_player = _pause_mode == PauseMode::Normal;
		if (!_networking && !this->game_paused_by_player) Command<Commands::Pause>::Post(PauseMode::Normal, true);

		/* Close all always on-top windows to get a clean screen */
		if (_game_mode != GameMode::Menu) HideVitalWindows();

		MarkWholeScreenDirty();
		this->window_number = difficulty; // show highscore chart for difficulty...
		this->background_img = SPR_HIGHSCORE_CHART_BEGIN; // which background to show
		this->rank = ranking;
	}

	void Close([[maybe_unused]] int data = 0) override
	{
		if (_game_mode != GameMode::Menu && !_exit_game) ShowVitalWindows();

		if (!_networking && !this->game_paused_by_player) Command<Commands::Pause>::Post(PauseMode::Normal, false); // unpause

		this->EndGameHighScoreBaseWindow::Close();
	}

	void OnPaint() override
	{
		const auto &hs = _highscore_table[this->window_number];

		this->SetupHighScoreEndWindow();
		Point pt = this->GetTopLeft(ScaleSpriteTrad(640), ScaleSpriteTrad(480));

		/* Draw the title. */
		DrawStringMultiLine(pt.x + ScaleSpriteTrad(70), pt.x + ScaleSpriteTrad(570), pt.y, pt.y + ScaleSpriteTrad(140), STR_HIGHSCORE_TOP_COMPANIES, TextColour::FromString, {AlignmentH::Centre, AlignmentV::Middle});

		/* Draw Highscore peepz */
		for (uint8_t i = 0; i < ClampTo<uint8_t>(hs.size()); i++) {
			DrawString(pt.x + ScaleSpriteTrad(40), pt.x + ScaleSpriteTrad(600), pt.y + ScaleSpriteTrad(140 + i * 55),
					GetString(STR_HIGHSCORE_POSITION, i + 1));

			if (!hs[i].name.empty()) {
				TextColour colour = (this->rank == i) ? TextColour::Red : TextColour::Black; // draw new highscore in red

				DrawString(pt.x + ScaleSpriteTrad(71), pt.x + ScaleSpriteTrad(569), pt.y + ScaleSpriteTrad(140 + i * 55),
						GetString(STR_JUST_BIG_RAW_STRING, hs[i].name), colour);
				DrawString(pt.x + ScaleSpriteTrad(71), pt.x + ScaleSpriteTrad(569), pt.y + ScaleSpriteTrad(140) + GetCharacterHeight(FontSize::Large) + ScaleSpriteTrad(i * 55),
						GetString(STR_HIGHSCORE_STATS, hs[i].title, hs[i].score), colour);
			}
		}
	}
};

static constexpr std::initializer_list<NWidgetPart> _nested_highscore_widgets = {
	NWidget(WWT_PANEL, Colours::Brown, WID_H_BACKGROUND), SetResize(1, 1), EndContainer(),
};

/** Window definition for the highscore window. */
static WindowDesc _highscore_desc(
	WindowPosition::Manual, {}, 0, 0,
	WindowClass::Highscore, WindowClass::None,
	{},
	_nested_highscore_widgets
);

/** Window definition for the endgame window. */
static WindowDesc _endgame_desc(
	WindowPosition::Manual, {}, 0, 0,
	WindowClass::Endscreen, WindowClass::None,
	{},
	_nested_highscore_widgets
);

/**
 * Show the highscore table for a given difficulty. When called from
 * endgame ranking is set to the top5 element that was newly added
 * and is thus highlighted
 * @param difficulty The difficulty level to show the high score for.
 * @param ranking The ranking to show the local company at.
 */
void ShowHighscoreTable(int difficulty, int8_t ranking)
{
	CloseWindowByClass(WindowClass::Highscore);
	new HighScoreWindow(_highscore_desc, difficulty, ranking);
}

/**
 * Show the endgame victory screen in 2050. Update the new highscore
 * if it was high enough
 */
void ShowEndGameChart()
{
	/* Dedicated server doesn't need the highscore window and neither does -v null. */
	if (_network_dedicated || (!_networking && !Company::IsValidID(_local_company))) return;

	HideVitalWindows();
	CloseWindowByClass(WindowClass::Endscreen);
	new EndGameWindow(_endgame_desc);
}

/** Yearly timer to check whether we want to show the end game chart. */
static const IntervalTimer<TimerGameCalendar> _check_end_game({TimerGameCalendar::Trigger::Year, TimerGameCalendar::Priority::None}, [](auto)
{
	/* 0 = never */
	if (_settings_game.game_creation.ending_year == 0) return;

	/* Show the end-game chart at the end of the ending year (hence the + 1). */
	if (TimerGameCalendar::year == _settings_game.game_creation.ending_year + 1) {
		ShowEndGameChart();
	}
});
