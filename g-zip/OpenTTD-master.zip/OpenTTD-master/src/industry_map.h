/*
 * This file is part of OpenTTD.
 * OpenTTD is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 2.
 * OpenTTD is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with OpenTTD. If not, see <https://www.gnu.org/licenses/old-licenses/gpl-2.0>.
 */

/** @file industry_map.h Accessors to map for industries. */

#ifndef INDUSTRY_MAP_H
#define INDUSTRY_MAP_H

#include "industrytype.h"
#include "water_map.h"


/**
 * Get the industry ID of the given tile
 * @param t the tile to get the industry ID from
 * @pre IsTileType(t, TileType::Industry)
 * @return the industry ID
 */
inline IndustryID GetIndustryIndex(Tile t)
{
	assert(IsTileType(t, TileType::Industry));
	return static_cast<IndustryID>(t.m2());
}

/**
 * Is this industry tile fully built?
 * @param t the tile to analyze
 * @pre IsTileType(t, TileType::Industry)
 * @return true if and only if the industry tile is fully built
 */
inline bool IsIndustryCompleted(Tile t)
{
	assert(IsTileType(t, TileType::Industry));
	return HasBit(t.m1(), 7);
}

IndustryType GetIndustryType(Tile tile);

/**
 * Set if the industry that owns the tile as under construction or not
 * @param tile the tile to query
 * @pre IsTileType(tile, TileType::Industry)
 */
inline void SetIndustryCompleted(Tile tile)
{
	assert(IsTileType(tile, TileType::Industry));
	SetBit(tile.m1(), 7);
}

/**
 * Returns the industry construction stage of the specified tile
 * @param tile the tile to query
 * @pre IsTileType(tile, TileType::Industry)
 * @return the construction stage
 */
inline uint8_t GetIndustryConstructionStage(Tile tile)
{
	assert(IsTileType(tile, TileType::Industry));
	return IsIndustryCompleted(tile) ? (uint8_t)INDUSTRY_COMPLETED : GB(tile.m1(), 0, 2);
}

/**
 * Sets the industry construction stage of the specified tile
 * @param tile the tile to query
 * @param value the new construction stage
 * @pre IsTileType(tile, TileType::Industry)
 */
inline void SetIndustryConstructionStage(Tile tile, uint8_t value)
{
	assert(IsTileType(tile, TileType::Industry));
	SB(tile.m1(), 0, 2, value);
}

/**
 * Get the industry graphics ID for the given industry tile as
 * stored in the without translation.
 * @param t the tile to get the gfx for
 * @pre IsTileType(t, TileType::Industry)
 * @return the gfx ID
 */
inline IndustryGfx GetCleanIndustryGfx(Tile t)
{
	assert(IsTileType(t, TileType::Industry));
	return t.m5() | (GB(t.m6(), 2, 1) << 8);
}

/**
 * Get the industry graphics ID for the given industry tile
 * @param t the tile to get the gfx for
 * @pre IsTileType(t, TileType::Industry)
 * @return the gfx ID
 */
inline IndustryGfx GetIndustryGfx(Tile t)
{
	assert(IsTileType(t, TileType::Industry));
	return GetTranslatedIndustryTileID(GetCleanIndustryGfx(t));
}

/**
 * Set the industry graphics ID for the given industry tile
 * @param t   the tile to set the gfx for
 * @pre IsTileType(t, TileType::Industry)
 * @param gfx the graphics ID
 */
inline void SetIndustryGfx(Tile t, IndustryGfx gfx)
{
	assert(IsTileType(t, TileType::Industry));
	t.m5() = GB(gfx, 0, 8);
	SB(t.m6(), 2, 1, GB(gfx, 8, 1));
}

/**
 * Returns this industry tile's construction counter value
 * @param tile the tile to query
 * @pre IsTileType(tile, TileType::Industry)
 * @return the construction counter
 */
inline uint8_t GetIndustryConstructionCounter(Tile tile)
{
	assert(IsTileType(tile, TileType::Industry));
	return GB(tile.m1(), 2, 2);
}

/**
 * Sets this industry tile's construction counter value
 * @param tile the tile to query
 * @param value the new value for the construction counter
 * @pre IsTileType(tile, TileType::Industry)
 */
inline void SetIndustryConstructionCounter(Tile tile, uint8_t value)
{
	assert(IsTileType(tile, TileType::Industry));
	SB(tile.m1(), 2, 2, value);
}

/**
 * Reset the construction stage counter of the industry,
 * as well as the completion bit.
 * In fact, it is the same as restarting construction from the ground up.
 * @param tile the tile to query
 * @pre IsTileType(tile, TileType::Industry)
 */
inline void ResetIndustryConstructionStage(Tile tile)
{
	assert(IsTileType(tile, TileType::Industry));
	SB(tile.m1(), 0, 4, 0);
	SB(tile.m1(), 7, 1, 0);
}

/**
 * Get the animation loop number
 * @param tile the tile to get the animation loop number of
 * @pre IsTileType(tile, TileType::Industry)
 * @return The loop/frame number.
 */
inline uint8_t GetIndustryAnimationLoop(Tile tile)
{
	assert(IsTileType(tile, TileType::Industry));
	return tile.m4();
}

/**
 * Set the animation loop number
 * @param tile the tile to set the animation loop number of
 * @param count the new animation frame number
 * @pre IsTileType(tile, TileType::Industry)
 */
inline void SetIndustryAnimationLoop(Tile tile, uint8_t count)
{
	assert(IsTileType(tile, TileType::Industry));
	tile.m4() = count;
}

/**
 * Get the random bits for this tile.
 * Used for grf callbacks
 * @param tile the tile to query
 * @pre IsTileType(tile, TileType::Industry)
 * @return requested bits
 */
inline uint8_t GetIndustryRandomBits(Tile tile)
{
	assert(IsTileType(tile, TileType::Industry));
	return tile.m3();
}

/**
 * Set the random bits for this tile.
 * Used for grf callbacks
 * @param tile the tile to query
 * @param bits the random bits
 * @pre IsTileType(tile, TileType::Industry)
 */
inline void SetIndustryRandomBits(Tile tile, uint8_t bits)
{
	assert(IsTileType(tile, TileType::Industry));
	tile.m3() = bits;
}

/**
 * Get the activated triggers bits for this industry tile
 * Used for grf callbacks
 * @param tile the tile to query
 * @pre IsTileType(tile, TileType::Industry)
 * @return requested triggers
 */
inline IndustryRandomTriggers GetIndustryRandomTriggers(Tile tile)
{
	assert(IsTileType(tile, TileType::Industry));
	return static_cast<IndustryRandomTriggers>(GB(tile.m6(), 3, 3));
}


/**
 * Set the activated triggers bits for this industry tile
 * Used for grf callbacks
 * @param tile the tile to query
 * @param triggers the triggers to set
 * @pre IsTileType(tile, TileType::Industry)
 */
inline void SetIndustryRandomTriggers(Tile tile, IndustryRandomTriggers triggers)
{
	assert(IsTileType(tile, TileType::Industry));
	SB(tile.m6(), 3, 3, triggers.base());
}

/**
 * Make the given tile an industry tile
 * @param t      the tile to make an industry tile
 * @param index  the industry this tile belongs to
 * @param gfx    the graphics to use for the tile
 * @param random the random value
 * @param wc     the water class for this industry; only useful when build on water
 */
inline void MakeIndustry(Tile t, IndustryID index, IndustryGfx gfx, uint8_t random, WaterClass wc)
{
	SetTileType(t, TileType::Industry);
	t.m1() = 0;
	t.m2() = index.base();
	SetIndustryRandomBits(t, random); // m3
	t.m4() = 0;
	SetIndustryGfx(t, gfx); // m5, part of m6
	SetIndustryRandomTriggers(t, {}); // rest of m6
	SetWaterClass(t, wc);
	SB(t.m6(), 6, 2, 0);
	t.m7() = 0;
	t.m8() = 0;
}

#endif /* INDUSTRY_MAP_H */
